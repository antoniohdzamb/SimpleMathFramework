//
//  SimpleMathFramework.h
//  SimpleMathFramework
//
//  Created by Jose Antonio Hernandez on 05/01/23.
//

#import <Foundation/Foundation.h>

//! Project version number for SimpleMathFramework.
FOUNDATION_EXPORT double SimpleMathFrameworkVersionNumber;

//! Project version string for SimpleMathFramework.
FOUNDATION_EXPORT const unsigned char SimpleMathFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SimpleMathFramework/PublicHeader.h>


